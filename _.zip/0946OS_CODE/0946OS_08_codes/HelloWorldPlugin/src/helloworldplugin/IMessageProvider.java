package helloworldplugin;

public interface IMessageProvider {
	
	public String getHelloMessage();
	
}
